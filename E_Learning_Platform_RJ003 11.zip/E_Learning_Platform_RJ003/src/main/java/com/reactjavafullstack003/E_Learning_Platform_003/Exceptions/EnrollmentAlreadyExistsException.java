package com.reactjavafullstack003.E_Learning_Platform_003.Exceptions;

public class EnrollmentAlreadyExistsException extends RuntimeException {
    public EnrollmentAlreadyExistsException(String message) {
        super(message);
    }

}
