package com.reactjavafullstack003.E_Learning_Platform_003.Exceptions;

public class EnrollmentNotFoundException extends RuntimeException {
    public EnrollmentNotFoundException(String message) {
        super(message);
    }

}
