package com.reactjavafullstack003.E_Learning_Platform_003.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.reactjavafullstack003.E_Learning_Platform_003.model.Video;
import com.reactjavafullstack003.E_Learning_Platform_003.service.VideoService;

import jakarta.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Validated
@RestController
@RequestMapping("/api/videos")
public class VideoController {
    private static final Logger logger = LogManager.getLogger(VideoController.class);
    @Autowired
    private VideoService videoService;

    @GetMapping
    public List<Video> getAllVideos() {
        logger.info("Fetching all videos");
        return videoService.getAllVideos();
    }

    @GetMapping("/course/{courseId}")
    public List<Video> getVideosByCourse(@PathVariable int courseId) {
        logger.info("Fetching videos for course with ID: {}", courseId);
        return videoService.getVideosByCourseId(courseId);
    }

    @PostMapping("/save")
    public Video addVideo(@Valid @RequestBody Video video) {
        logger.info("Adding video");
        return videoService.addVideo(video);
    }

    @DeleteMapping("/{videoId}")
    public void deleteVideo(@PathVariable int videoId) {
        logger.info("Deleting video with ID: {}", videoId);
        videoService.deleteVideo(videoId);
    }
    @PutMapping("/complete/{videoId}")
    public Video markAsCompleted(@PathVariable int videoId) {
        logger.info("Marking video as completed with ID: {}", videoId);
        return videoService.markAsCompleted(videoId);
    }
}