package com.reactjavafullstack003.E_Learning_Platform_003.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reactjavafullstack003.E_Learning_Platform_003.Exceptions.EnrollmentNotFoundException;
import com.reactjavafullstack003.E_Learning_Platform_003.model.Assessment;
import com.reactjavafullstack003.E_Learning_Platform_003.model.Enrollment;
import com.reactjavafullstack003.E_Learning_Platform_003.model.Video;
import com.reactjavafullstack003.E_Learning_Platform_003.repository.AssessmentRepository;
import com.reactjavafullstack003.E_Learning_Platform_003.repository.EnrollmentRepository;
import com.reactjavafullstack003.E_Learning_Platform_003.repository.VideoRepository;

@Service
public class EnrollmentService {

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private VideoRepository videoRepository;

    @Autowired
    private AssessmentRepository assessmentRepository;

    public List<Enrollment> getAllEnrollments() {
        if (enrollmentRepository.findAll().isEmpty()) {
            throw new EnrollmentNotFoundException("No enrollments found");
        }
        return enrollmentRepository.findAll();
    }

    public Enrollment getEnrollmentById(int enrollmentID) {
        return enrollmentRepository.findById(enrollmentID)
        .orElseThrow(() -> new EnrollmentNotFoundException("Enrollment not found with ID: " + enrollmentID));   
    }

    public Enrollment enroll(Enrollment enrollment) {
        if (enrollmentRepository.findByCourseIDAndStudentid(enrollment.getCourseID(), enrollment.getStudentid()).isPresent()) {
            throw new EnrollmentNotFoundException("Enrollment already exists for courseID: " + enrollment.getCourseID() + " and userID: " + enrollment.getStudentid());
        }
        return enrollmentRepository.save(enrollment);
    }
    public Enrollment updateEnrollment(int enrollmentID, Enrollment enrollment) {
        Enrollment existingEnrollment = enrollmentRepository.findById(enrollmentID).orElse(null);
        if (existingEnrollment != null) {
            existingEnrollment.setStatus(enrollment.getStatus());
            existingEnrollment.setProgress(enrollment.getProgress());
            // Update other fields as necessary
            return enrollmentRepository.save(existingEnrollment);
        } else {
            return null;
        }
    }
    public void deleteEnrollment(int enrollmentID) {
        if (enrollmentRepository.findById(enrollmentID).isEmpty()) {
            throw new EnrollmentNotFoundException("Enrollment not found with ID: " + enrollmentID);
        }
        enrollmentRepository.deleteById(enrollmentID);
    }
    public void updateProgress(int enrollmentID) {
        Enrollment enrollment = getEnrollmentById(enrollmentID);
        if (enrollment != null) {
                List<Video> videos = videoRepository.findByCourseId(enrollment.getCourseID());
                List<Assessment> assessments = assessmentRepository.findByCourseID(enrollment.getCourseID());
                
                int completedVideos = (int) videos.stream().filter(Video::isCompleted).count();
                int completedAssessments = (int) assessments.stream().filter(Assessment::isCompleted).count();
                
                int totalVideos = videos.size();
                int totalAssessments = assessments.size();
                int totalTasks = totalVideos + totalAssessments;
                int completedTasks = completedVideos + completedAssessments;
                
                int progress = (int) ((double) completedTasks / totalTasks * 100);
                
                enrollment.setProgress(progress);
                
                enrollmentRepository.save(enrollment);
            }
        }
        
       public boolean isCompleted(int enrollmentID) {
        Enrollment enrollment = getEnrollmentById(enrollmentID);
        if (enrollment != null) {
            List<Video> videos = videoRepository.findByCourseId(enrollment.getCourseID());
            List<Assessment> assessments = assessmentRepository.findByCourseID(enrollment.getCourseID());
            
            boolean allVideosCompleted = videos.stream().allMatch(Video::isCompleted);
            boolean allAssessmentsCompleted = assessments.stream().allMatch(Assessment::isCompleted);

            return allVideosCompleted && allAssessmentsCompleted;
        }
        return false;
    }
}
