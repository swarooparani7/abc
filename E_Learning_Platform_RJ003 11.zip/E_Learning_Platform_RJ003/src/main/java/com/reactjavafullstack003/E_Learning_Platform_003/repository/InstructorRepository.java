package com.reactjavafullstack003.E_Learning_Platform_003.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reactjavafullstack003.E_Learning_Platform_003.model.Instructor;

public interface InstructorRepository extends JpaRepository<Instructor, Integer> {
    Optional<Instructor> findByEmail(String email);
}
