package com.reactjavafullstack003.E_Learning_Platform_003.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reactjavafullstack003.E_Learning_Platform_003.Exceptions.CourseNotFoundException;
import com.reactjavafullstack003.E_Learning_Platform_003.model.Course;
import com.reactjavafullstack003.E_Learning_Platform_003.repository.CourseRepository;

@Service
public class CourseService {
    @Autowired
    private CourseRepository courseRepository;

    public List<Course> getAllCourses() {
        if (courseRepository.findAll().isEmpty()) {
            throw new CourseNotFoundException("No courses found");
        }
        return courseRepository.findAll();
    }

    public Course getCourseById(int courseID) {
        return courseRepository.findById(courseID)
        .orElseThrow(() -> new CourseNotFoundException("Course not found with ID: " + courseID));
    }

    public Course saveCourse(Course course) {
        if (courseRepository.findByTitle(course.getTitle()).isPresent()) {
            throw new CourseNotFoundException("Course already exists with title: " + course.getTitle());
        }
        return courseRepository.save(course);
    }

    public void deleteCourse(int courseID) {
        if (courseRepository.findById(courseID).isEmpty()) {
            throw new CourseNotFoundException("Course not found with ID: " + courseID);
        }
        courseRepository.deleteById(courseID);
    }
    public Course updateCourse(int courseID, Course course) {
        Course existingCourse = courseRepository.findById(courseID).orElse(null);
        if (existingCourse != null) {
            existingCourse.setTitle(course.getTitle());
            existingCourse.setDescription(course.getDescription());
            existingCourse.setContentURL(course.getContentURL());
            existingCourse.setInstructorID(course.getInstructorID());
            // Update other fields as necessary
            return courseRepository.save(existingCourse);
        } else {
            return null;
        }
    }
	public Course createCourse(Course course) {
		
		return null;
	}
}