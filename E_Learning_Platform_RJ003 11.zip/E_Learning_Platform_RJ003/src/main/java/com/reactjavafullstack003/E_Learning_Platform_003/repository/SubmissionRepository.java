package com.reactjavafullstack003.E_Learning_Platform_003.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reactjavafullstack003.E_Learning_Platform_003.model.Submission;

public interface SubmissionRepository extends JpaRepository<Submission, Integer> {


	List<Submission> findByStudentId(int studentId);
	List<Submission> findByAssessmentId(int assessmentId);

}
