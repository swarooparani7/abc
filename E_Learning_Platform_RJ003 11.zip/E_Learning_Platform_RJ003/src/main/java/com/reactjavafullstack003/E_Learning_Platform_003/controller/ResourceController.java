package com.reactjavafullstack003.E_Learning_Platform_003.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import com.reactjavafullstack003.E_Learning_Platform_003.model.Resource;
import com.reactjavafullstack003.E_Learning_Platform_003.service.ResourceService;

import jakarta.validation.Valid;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Validated
@RestController
@RequestMapping("/api/resources")
public class ResourceController {
    private static final Logger logger = LogManager.getLogger(ResourceController.class);

    @Autowired
    private ResourceService resourceService;

    @GetMapping
    public List<Resource> getAllResources() {
        logger.info("Fetching all resources");
        return resourceService.getAllResources();
    }

    @GetMapping("/course/{courseId}")
    public List<Resource> getResourcesByCourse(@PathVariable int courseId) {
        logger.info("Fetching resources for course with ID: {}", courseId);
        return resourceService.getResourcesByCourseId(courseId);
    }

    @PostMapping("/save")
    public Resource addResource(@Valid @RequestBody Resource resource) {
        logger.info("Adding resource");
        return resourceService.addResource(resource);
    }

    @DeleteMapping("/{resourceId}")
    public void deleteResource(@PathVariable int resourceId) {
        logger.info("Deleting resource with ID: {}", resourceId);
        resourceService.deleteResource(resourceId);
    }
}