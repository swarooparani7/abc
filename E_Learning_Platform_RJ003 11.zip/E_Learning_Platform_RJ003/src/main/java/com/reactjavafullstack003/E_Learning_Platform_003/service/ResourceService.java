package com.reactjavafullstack003.E_Learning_Platform_003.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.reactjavafullstack003.E_Learning_Platform_003.model.Resource;
import com.reactjavafullstack003.E_Learning_Platform_003.repository.ResourceRepository;
import java.util.List;

@Service
public class ResourceService {
    @Autowired
    private ResourceRepository resourceRepository;

    public List<Resource> getAllResources() {
        return resourceRepository.findAll();
    }

    public List<Resource> getResourcesByCourseId(int courseId) {
        if (resourceRepository.findByCourseId(courseId).isEmpty()) {
            throw new RuntimeException("No resources found for course with ID: " + courseId);
        }
        return resourceRepository.findByCourseId(courseId);
    }

    public Resource addResource(Resource resource) {
        
        return resourceRepository.save(resource);
    }

    public void deleteResource(int resourceId) {
        resourceRepository.deleteById(resourceId);
    }
}