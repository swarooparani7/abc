package com.reactjavafullstack003.E_Learning_Platform_003.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.reactjavafullstack003.E_Learning_Platform_003.model.Assessment;
import com.reactjavafullstack003.E_Learning_Platform_003.model.Attempt;
import com.reactjavafullstack003.E_Learning_Platform_003.model.Submission;
import com.reactjavafullstack003.E_Learning_Platform_003.service.AssessmentService;
import com.reactjavafullstack003.E_Learning_Platform_003.service.NotificationService;
import com.reactjavafullstack003.E_Learning_Platform_003.service.SubmissionService;

import jakarta.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Validated
@RestController
@RequestMapping("/api/assessments")
public class AssessmentController {
    private static final Logger logger = LogManager.getLogger(AssessmentController.class);
     @Autowired
    private AssessmentService assessmentService;
    
    @Autowired
    public SubmissionService submissionService;

    @Autowired
    public NotificationService notificationService;

    @GetMapping
    public List<Assessment> getAllAssessments() {
        return assessmentService.getAllAssessments();
    }

    @GetMapping("/{assessmentID}")
    public ResponseEntity<Assessment> getAssessmentById(@PathVariable int assessmentID) {
        logger.info("Fetching assessment with ID: {}", assessmentID);
       
        Optional<Assessment> assessmentOpt = assessmentService.getAssessmentById(assessmentID);
        if (assessmentOpt.isPresent()) {
            Assessment assessment = assessmentOpt.get();
            return new ResponseEntity<>(assessment, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public Assessment createAssessment(@Valid @RequestBody Assessment assessment) {
        logger.info("Creating assessment");
        notificationService.saveNotification("Assement created");
        return assessmentService.saveAssessment(assessment);
    }

    @PostMapping("/attempt")
    public ResponseEntity<Double> createAttempt(@RequestBody Attempt attempt) {
        logger.info("Creating attempt");
        notificationService.saveNotification("Attempt created");
        Attempt savedAttempt = assessmentService.saveAttempt(attempt);
        double grade = assessmentService.calculateGrade(savedAttempt);
        return new ResponseEntity<>(grade, HttpStatus.CREATED);
    }

    @PostMapping("/{assessmentId}/attempt")
    public ResponseEntity<Submission> attemptAssessment(@PathVariable int assessmentId,@Valid @RequestBody Attempt attempt) {
        logger.info("Attempting assessment");
        notificationService.saveNotification("Attempting assessment");
        Optional<Assessment> assessmentOpt = assessmentService.getAssessmentById(assessmentId);
        if (!assessmentOpt.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        Assessment assessment = assessmentOpt.get();
        double score = calculateScore(assessment, attempt.getAnswers());

        Submission submission = new Submission();
        submission.setScore(score);
        submission.setStudentId(attempt.getUserID());
        submission.setAssessmentId(assessmentId);
        submission.setSubmissionDate(LocalDateTime.now());

        Submission savedSubmission = submissionService.saveSubmission(submission);
        return new ResponseEntity<>(savedSubmission, HttpStatus.CREATED);
    }

    private double calculateScore(Assessment assessment, Map<String, String> answers) {
        double score = 0.0;
        Map<String, String> correctAnswers = assessment.getQuestions();
        for (Map.Entry<String, String> entry : correctAnswers.entrySet()) {
            String question = entry.getKey();
            String correctAnswer = entry.getValue();
            String userAnswer = answers.get(question);
            if (correctAnswer.equals(userAnswer)) {
                score += 1.0; // Increment score for each correct answer
            }
        }
        return score;
    }

    @DeleteMapping("/{assessmentID}")
    public ResponseEntity<Void> deleteAssessment(@PathVariable int assessmentID) {
        logger.info("Deleting assessment with ID: {}", assessmentID);
        assessmentService.deleteAssessment(assessmentID);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}