package com.reactjavafullstack003.E_Learning_Platform_003.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.reactjavafullstack003.E_Learning_Platform_003.Exceptions.ResourceNotFoundException;
import com.reactjavafullstack003.E_Learning_Platform_003.model.Enrollment;
import com.reactjavafullstack003.E_Learning_Platform_003.service.EnrollmentService;
import com.reactjavafullstack003.E_Learning_Platform_003.service.NotificationService;

import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.RequestParam;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Validated
@RestController
@RequestMapping("/api/enrollments")
public class EnrollmentController {
    
    private static final Logger logger = LogManager.getLogger(EnrollmentController.class);

    @Autowired
    private EnrollmentService enrollmentService;

     @Autowired
    private NotificationService notificationService ;

    @GetMapping
    public List<Enrollment> getAllEnrollments() {
        logger.info("Fetching all enrollments");
        return enrollmentService.getAllEnrollments();
    }

    @GetMapping("/{enrollmentID}")
    public ResponseEntity<Enrollment> getEnrollmentById(@PathVariable int enrollmentID) {
        logger.info("Fetching enrollment with ID: {}", enrollmentID);
        Enrollment enrollment = enrollmentService.getEnrollmentById(enrollmentID);
        if (enrollment != null) {
            return new ResponseEntity<>(enrollment, HttpStatus.OK);
        } else {
            throw new ResourceNotFoundException("Enrollment not found with id: " + enrollmentID);
        }
    }

    @PostMapping
    public Enrollment saveEnrollment(@Valid @RequestBody Enrollment enrollment) {
        logger.info("Saving enrollment");
        notificationService.saveNotification("Saving enrollment");
        return enrollmentService.enroll(enrollment);
    }
    @PutMapping("/{enrollmentID}")
    public ResponseEntity<Enrollment> updateEnrollment(@PathVariable int enrollmentID,@Valid @RequestBody Enrollment enrollment) {
        logger.info("Updating enrollment with ID: {}", enrollmentID);
        Enrollment updatedEnrollment = enrollmentService.updateEnrollment(enrollmentID, enrollment);
        if (updatedEnrollment != null) {
            return new ResponseEntity<>(updatedEnrollment, HttpStatus.OK);
        } else {
          throw new ResourceNotFoundException("Enrollment not found with id: " + enrollmentID);
        }
    }

    @DeleteMapping("/{enrollmentID}")
    public ResponseEntity<Void> deleteEnrollment(@PathVariable int enrollmentID) {
        logger.info("Deleting enrollment with ID: {}", enrollmentID);
        enrollmentService.deleteEnrollment(enrollmentID);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/updateProgress/{enrollmentID}")
    public ResponseEntity<Enrollment> updateProgress(@PathVariable int enrollmentID) {
        logger.info("Updating progress for enrollment with ID: {}", enrollmentID);
        enrollmentService.updateProgress(enrollmentID);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/progress/{enrollmentID}")
    public ResponseEntity<Integer> getProgress(@PathVariable int enrollmentID){
       logger.info("Fetching progress for enrollment with ID: {}", enrollmentID);
        Enrollment enrollment = enrollmentService.getEnrollmentById(enrollmentID);
        if(enrollment != null){
            return new ResponseEntity<>(enrollment.getProgress(), HttpStatus.OK);
        } else {
            throw new ResourceNotFoundException("Enrollment not found with id: " + enrollmentID);
        }
    }
    @GetMapping("/isCompleted/{enrollmentID}")
    public ResponseEntity<Boolean> isCourseCompleted(@PathVariable int enrollmentID) {
        logger.info("Checking if enrollment with ID: {} is completed", enrollmentID);
        boolean isCompleted = enrollmentService.isCompleted(enrollmentID);
        return new ResponseEntity<>(isCompleted, HttpStatus.OK);
    }
    
}
