/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.reactjavafullstack003.E_Learning_Platform_003.Exceptions;


class InstructorAlreadyExistsException extends RuntimeException {

    public InstructorAlreadyExistsException(String message) {
        super(message);
    }

}
