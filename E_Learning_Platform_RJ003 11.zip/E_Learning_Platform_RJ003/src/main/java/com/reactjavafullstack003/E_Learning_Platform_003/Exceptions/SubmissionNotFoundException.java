package com.reactjavafullstack003.E_Learning_Platform_003.Exceptions;

public class SubmissionNotFoundException extends RuntimeException {
    public SubmissionNotFoundException(String message) {
        super(message);
    }

}
