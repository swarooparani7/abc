package com.reactjavafullstack003.E_Learning_Platform_003.Exceptions;

public class SubmissionAlreadyExistsException  extends RuntimeException {
    public SubmissionAlreadyExistsException(String message) {
        super(message);
    }

}
