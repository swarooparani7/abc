package com.reactjavafullstack003.E_Learning_Platform_003.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.reactjavafullstack003.E_Learning_Platform_003.Exceptions.ResourceNotFoundException;
import com.reactjavafullstack003.E_Learning_Platform_003.model.Course;
import com.reactjavafullstack003.E_Learning_Platform_003.service.CourseService;
import com.reactjavafullstack003.E_Learning_Platform_003.service.NotificationService;

import jakarta.validation.Valid;

import org.springframework.security.access.prepost.PreAuthorize;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Validated
@RestController
@RequestMapping("/api/courses")
public class CourseController {

    
    private static final Logger logger = LogManager.getLogger(CourseController.class);
    @Autowired
    private CourseService courseService;
    @Autowired
    private NotificationService notificationService ;

    @GetMapping
    public List<Course> getAllCourses() {
        logger.info("Fetching all courses");
        return courseService.getAllCourses();
    }

    @GetMapping("/{courseID}")
    public ResponseEntity<Course> getCourseById(@PathVariable int courseID) {
        logger.info("Fetching course with ID: {}", courseID);
        Course course = courseService.getCourseById(courseID);
        if (course != null) {
            return new ResponseEntity<>(course, HttpStatus.OK);
        } else {
            throw new ResourceNotFoundException("Course not found with id :"+courseID);
        }
    }

    @PutMapping("/{courseID}")
    public ResponseEntity<Course> updateCourse(@PathVariable int courseID,@Valid @RequestBody Course course) {
        logger.info("Updating course with ID: {}", courseID);
        Course updatedCourse = courseService.updateCourse(courseID, course);
        if (updatedCourse != null) {
            return new ResponseEntity<>(updatedCourse, HttpStatus.OK);
        } else {
            throw new ResourceNotFoundException("Course not found with id: " + courseID);
        }
    }

    @PostMapping("/save")
    public Course saveCourse(@Valid @RequestBody Course course) {
        logger.info("Saving new course");
        notificationService.saveNotification("Course Create ");
        return courseService.saveCourse(course);
    }

    @DeleteMapping("/{courseID}")

    public ResponseEntity<Void> deleteCourse(@PathVariable int courseID) {
        logger.info("Deleting course with ID: {}", courseID);
        courseService.deleteCourse(courseID);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}