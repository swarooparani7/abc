package com.reactjavafullstack003.E_Learning_Platform_003.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.reactjavafullstack003.E_Learning_Platform_003.model.Resource;
import java.util.List;

public interface ResourceRepository extends JpaRepository<Resource, Integer> {
    List<Resource> findByCourseId(int courseId);
}