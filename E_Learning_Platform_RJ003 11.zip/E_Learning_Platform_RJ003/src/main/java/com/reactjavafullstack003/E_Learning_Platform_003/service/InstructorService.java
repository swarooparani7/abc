package com.reactjavafullstack003.E_Learning_Platform_003.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reactjavafullstack003.E_Learning_Platform_003.Exceptions.InstructorNotFoundException;
import com.reactjavafullstack003.E_Learning_Platform_003.model.Instructor;
import com.reactjavafullstack003.E_Learning_Platform_003.repository.InstructorRepository;

@Service
public class InstructorService {
    @Autowired
    private InstructorRepository instructorRepository;

    public List<Instructor> getAllInstructors() {
        List<Instructor> instructors = instructorRepository.findAll();
        if (instructors.isEmpty()) {
            throw new InstructorNotFoundException("No instructors found");
        }
        return instructors;
    }

    public Instructor getInstructorById(int instructorID) {
        return instructorRepository.findById(instructorID)
                .orElseThrow(() -> new InstructorNotFoundException("Instructor with ID " + instructorID + " not found"));
    }

    public Instructor saveInstructor(Instructor instructor) {
        if (instructorRepository.findByEmail(instructor.getEmail()).isPresent()) {
            throw new InstructorNotFoundException("Instructor already exists with email: " + instructor.getEmail());
        }
        return instructorRepository.save(instructor);
    }

    public void deleteInstructor(int instructorID) {
        if (!instructorRepository.existsById(instructorID)) {
            throw new InstructorNotFoundException("Instructor with ID " + instructorID + " not found");
        }
        instructorRepository.deleteById(instructorID);
    }
}