package com.reactjavafullstack003.E_Learning_Platform_003.controller;


import com.reactjavafullstack003.E_Learning_Platform_003.model.Instructor;
import com.reactjavafullstack003.E_Learning_Platform_003.service.InstructorService;
import com.reactjavafullstack003.E_Learning_Platform_003.service.NotificationService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.List;

@Validated
@RestController
@RequestMapping("/api/instructors")
public class InstructorController {
    private static final Logger logger = LogManager.getLogger(InstructorController.class);
    @Autowired
    private InstructorService instructorService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private NotificationService notificationService ;

    @GetMapping
    public List<Instructor> getAllInstructors() {
        logger.info("Fetching all instructors");
        return instructorService.getAllInstructors();
    }

    @GetMapping("/{instructorID}")
    public ResponseEntity<Instructor> getInstructorById(@PathVariable int instructorID) {
        logger.info("Fetching instructor with ID: {}", instructorID);
        Instructor instructor = instructorService.getInstructorById(instructorID);
        if (instructor != null) {
            return new ResponseEntity<>(instructor, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public Instructor createInstructor(@Valid @RequestBody Instructor instructor) {
        logger.info("Creating instructor");
        notificationService.saveNotification("Creating Instructors") ;
        instructor.setPassword(passwordEncoder.encode(instructor.getPassword()));
        return instructorService.saveInstructor(instructor);
    }

    @DeleteMapping("/{instructorID}")
    public ResponseEntity<Void> deleteInstructor(@PathVariable int instructorID) {
        logger.info("Deleting instructor with ID: {}", instructorID);
        instructorService.deleteInstructor(instructorID);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}