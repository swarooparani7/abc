package com.reactjavafullstack003.E_Learning_Platform_003.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reactjavafullstack003.E_Learning_Platform_003.model.Assessment;


public interface AssessmentRepository extends JpaRepository<Assessment, Integer>{

	 List<Assessment> findByAssessmentID(int assessmentID);
	 List<Assessment> findByCourseID(int assessmentID);
	}
	
