package com.reactjavafullstack003.E_Learning_Platform_003.Exceptions;

public class AssessmentNotFoundException  extends RuntimeException {
    public AssessmentNotFoundException(String message) {
        super(message);
    }

}
