package com.reactfullstack003.ElearningPlatform_;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElearningPlatformApplicationTests {

	
	@Test
	void contextLoads() {
	}

}
